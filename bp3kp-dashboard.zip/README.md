# Dashboard Internal BP3KP JAWA IV

Dashboard internal berbasis HTML dengan fitur login dan CAPTCHA sederhana. Digunakan untuk mengakses berbagai tautan penting BP3KP Jawa IV.

## Login Default
- Username: `bp3kp`
- Password: `jawa4`

## Fitur
- Login lokal dengan validasi
- CAPTCHA penjumlahan
- Link internal instansi
- Logout session

## Cara Pakai
1. Buka `index.html` di browser.
2. Masukkan kredensial dan CAPTCHA.
3. Akses dashboard link.
